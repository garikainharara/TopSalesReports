import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  isAlert = false;
  isAlert1 = false;

  constructor(private http:HttpClient, private router: Router) { 
    let lastname = localStorage.getItem("key");
    if(lastname!=null)
    {
      if(lastname=="true")
      {
        alert("Successfully created user")
      }
    }
  }
  goOtp(){
    this.router.navigate(['/OTP']);  // define your component where you want to go
 }
 regUser(){
  this.router.navigate(['/reg']);  // define your component where you want to go
}

  ngOnInit(): void {
  }
  loginUser(signInForm: NgForm)
  {
    localStorage.setItem("key", "false");
    console.log(signInForm.value.EmailNameField);
    console.log(signInForm.value.PasswordField);

    let url = "https://localhost:44329/api/Assignment3/LoginUser";
 

    this.http.post(url,{
      userName: signInForm.value.EmailNameField,
      passWord :signInForm.value.PasswordField
    }).toPromise().then((data:any)=>{
      console.log(data)
      if(data == true)
      {
        this.goOtp();
      }
      else
      {
        alert("Incorrect password")

      }
    }) 
  }

}

