import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reguser',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private http:HttpClient, private router: Router) { }
  isAlert = false;
  ngOnInit(): void {
  }
  goOtp(){
    this.router.navigate(['']);  // define your component where you want to go
 }
  loginUser(signInForm: NgForm)
  {
    let url = "https://localhost:44329/api/Assignment3/CreateUser";

    this.http.post(url,{
      userName: signInForm.value.EmailNameField,
      passWord :signInForm.value.PasswordField
    }).toPromise().then((data:any)=>{
      console.log(data)
      if(data == true)
      {
        localStorage.setItem("key", "true");
        this.goOtp(); //success
      }
      else
      {
        alert("Invalid mail user already exists")
      }
    }) 

  }

}
