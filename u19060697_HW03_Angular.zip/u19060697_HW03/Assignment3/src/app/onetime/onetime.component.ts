import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-onetime',
  templateUrl: './onetime.component.html',
  styleUrls: ['./onetime.component.css']
})
export class OnetimeComponent implements OnInit {
  isAlert = false;
  constructor(private http:HttpClient, private router: Router) { }
  goOtp(){
    this.router.navigate(['/dash']);  // define your component where you want to go
 }
  ngOnInit(): void {
  }

  loginUser(signInForm: NgForm)
  {
    console.log(signInForm.value.OTPField);



    let url = "https://localhost:44329/api/Assignment3/OTPch";

    this.http.post(url,
      parseInt(signInForm.value.OTPField)
    ).toPromise().then((data:any)=>{
      console.log(data)
      if(data == true)
      {
        this.goOtp()
      }
      else
      {
        alert("Incorrect OTP PIN")
      }
    }) 

  }

}

