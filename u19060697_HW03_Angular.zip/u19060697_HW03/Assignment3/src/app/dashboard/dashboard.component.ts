import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { ChartType, ChartOptions } from 'chart.js';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  Brand: any;
   a:any;
   brands : any;
   brandq : any;

   types : any;
   typesq: any;
   prods: any; 

  constructor(private httpClient: HttpClient) {
    this.getProducts();
  }
  getProducts() 
   {
    this.httpClient.get<any>('https://localhost:44329/api/Assignment3/getTopTen').subscribe(
       response => {
         this.prods = response;
        
         response.forEach(function (value: any) 
         {
             if(value.productTypeId==1)
             {
              value.productType = "Footwear";
             }
             if(value.productTypeId==2)
             {
              value.productType = "Clothing";
             }
             if(value.productTypeId==3)
             {
              value.productType = "Accessories";
             }

             if(value.brandId==1)
             {
              value.brand = "Nike";
             }
             if(value.brandId==2)
             {
              value.brand = "Adidas";
             }
             if(value.brandId==3)
             {
              value.brand = "Levi Strauss & Co.";
             }


         }
      );
         return  response;       
       } 
     );
   }
  
  ngOnInit(){
   
    this.httpClient.get<any>('https://localhost:44329/api/Assignment3/getBrandData').subscribe(
      response => {
        this.Brand = response;  
      
       
       this.brands = response.map((a: { brand: any; }) => a.brand);

       this.brandq = response.map((a: { items: any; })  => a.items);

       localStorage.setItem("key1", this.brands);
       localStorage.setItem("key2", this.brandq);
      
      } 
    );

    this.httpClient.get<any>('https://localhost:44329/api/Assignment3/getTypeData').subscribe(
      response => {
        this.Brand = response;  
    
       
       this.types = response.map((a: { type: any; }) => a.type);

       this.typesq = response.map((a: { items: any; }) => a.items);

       localStorage.setItem("keys1", this.types);
       localStorage.setItem("keys2", this.typesq);
       

      } 
    );

   

    var key1  = localStorage.getItem("key1")+"";
    var key2  = localStorage.getItem("key2")+"";
    var nameArr = key1.split(',');
    var numArr = key2.split(',').map(Number);

    var keys1  = localStorage.getItem("keys1")+"";
    var keys2  = localStorage.getItem("keys2")+"";
    var tnameArr = keys1.split(',');
    var tnumArr = keys2.split(',').map(Number);

   
    const ctx = 'myChart';

    const myChart = new Chart(ctx, {
      type: "pie",
      data:{
        labels:nameArr,
        datasets: [{
          label: 'My First Dataset',
          data:numArr,
          backgroundColor: [
            'rgb(255, 99, 132)',
            'rgb(54, 162, 235)',
            'rgb(255, 205, 86)'
          ],
          hoverOffset: 4
        }]

      }
      
    });

    const ctx1 = 'myCharts';
    const myCharts = new Chart(ctx1, {
      type: "pie",
      data:{
        labels:tnameArr,
        datasets: [{
          label: 'My First Dataset',
          data:tnumArr,
          backgroundColor: [
            'rgb(255, 99, 132)',
            'rgb(54, 162, 235)',
            'rgb(255, 205, 86)'
          ],
          hoverOffset: 4
        }]

      }
      
    });

   
   



  }

}