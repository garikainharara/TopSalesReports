﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Mvc;

namespace Assignment3_API.Models
{
    public class Login
    {
        [Key]
        public int userID { get; set; }
        public string userName { get; set; }
        public string passWord { get; set; }





    }
}
