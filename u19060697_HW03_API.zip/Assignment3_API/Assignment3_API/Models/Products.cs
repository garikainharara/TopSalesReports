﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment3_API.Models
{
    public class Products : BaseEntity
    {   
        [Key]
        public int ProductId { get; set; }

        [Column(TypeName = "decimal(18,3)")]
        public decimal Price { get; set; }
        public virtual ProductType ProductType { get; set; }
        public virtual Brands Brand { get; set; }

        //This allows us to get Product & Brand Ids by foreign keys 
        [ForeignKey("ProductTypes")]
        public int ProductTypeId { get; set; }

        [ForeignKey("Brands")]
        public int BrandId { get; set; }
    }
}
