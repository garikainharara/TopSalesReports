﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment3_API.Models
{
    public class Brands : BaseEntity
    {     
        [Key]
        public int BrandId { get; set; }
        public virtual ICollection<Products> Products { get; set; }
    }
}
