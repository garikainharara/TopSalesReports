﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Assignment3_API.Models;
using System;
using System.Text;
using System.Linq;
using Newtonsoft.Json;
using System.Net.Mail;
using System.Net;


namespace Assignment3_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Assignment3Controller : ControllerBase
    {
        private AppDbContext _dbContext;
        static int OTP;
        public Assignment3Controller(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        //Method for hasing the user password
        public string Hash(string password)
        {
            var bytes = new UTF8Encoding().GetBytes(password);
            var hashBytes = System.Security.Cryptography.MD5.Create().ComputeHash(bytes);
            return Convert.ToBase64String(hashBytes);
        }



        [HttpGet("GetUsers")]
        public IActionResult getUsers()
        {
            try
            {
                var users = _dbContext.Login.ToList();

                if (users.Count == 0)
                {
                    return StatusCode(404);
                }
                else
                {
                    return Ok(users);
                }
            }
            catch
            {
                return StatusCode(500, "Something went wrong");
            }



        }

        
        //Top 10 list  
        [HttpGet("getTopTen")]
        public IActionResult getTopTen()
        {
            try
            {
                var users = _dbContext.Products.ToList();

                if (users.Count == 0)
                {
                    return StatusCode(404);
                }
                else
                {

                    var top10 = users.OrderByDescending(o => o.Price).Take(10);


                    return Ok(top10);
                }
            }
            catch
            {
                return StatusCode(500, "Something went wrong");
            }
        }



        [HttpGet("getBrandData")]
        public IActionResult getBrandData()
        {
            try
            {
                var users = _dbContext.Products.ToList();

                int tot = users.Count(x => x.ProductTypeId > 0);

                int cnike = users.Count(x => x.BrandId == 1);
                int Adidas = users.Count(x => x.BrandId == 2);
                int Levi = users.Count(x => x.BrandId == 3);



                var configs = new[]
                {
                 new {id =0, brand = "Nike",   items = cnike},
                 new {id =1, brand = "Adidas", items = Adidas},
                 new {id=2, brand = "Levi Strauss & Co.",   items = Levi}
                };

                var jsonData = JsonConvert.SerializeObject(configs);

                return Ok(jsonData);
            }
            catch
            {
                return StatusCode(500, "Something went wrong");
            }
        }

       
        // Test data 
        [HttpGet("getTypeData")]
        public IActionResult getTypeData()
        {
            try
            {
                var users = _dbContext.Products.ToList();

                int tot = users.Count(x => x.ProductTypeId > 0);

                int cnike = users.Count(x => x.ProductTypeId == 1);
                int Adidas = users.Count(x => x.ProductTypeId == 2);
                int Levi = users.Count(x => x.ProductTypeId == 3);



                var configs = new[]
                {
                 new {id =0, type = "Footwear",   items = cnike},
                 new {id =1, type = "Clothing", items = Adidas},
                 new {id=2, type = "Accessories",   items = Levi}
                };

                var jsonData = JsonConvert.SerializeObject(configs);

                return Ok(jsonData);
            }
            catch
            {
                return StatusCode(500, "Something went wrong");
            }

        }



        [HttpPost("LoginUser")]
        public IActionResult LoginUser([FromBody] Login login)
        {
            try
            {
                var users = _dbContext.Login.ToList();

                if (users.Count == 0)
                {
                    return StatusCode(404);
                }
                else
                {


                    foreach (var item in users)
                    {
                        if (login.userName == item.userName && Hash(login.passWord) == item.passWord)
                        {
                            Email(login.userName);
                            return Ok(true);
                        }

                    }
                    return Ok(false);

                }

            }
            catch
            {
                return StatusCode(500, "Something went wrong");
            }
        }
        



        public static void Email(string email)
        {
            Random random = new Random();
            OTP = random.Next(1000, 9999);

            try
            {
                MailMessage message = new MailMessage();
                SmtpClient smtp = new SmtpClient();
                message.From = new MailAddress("Siyandand1@gmail.com");
                message.To.Add(new MailAddress(email));
                message.Subject = "OTP Login code";
                message.IsBodyHtml = true; //to make message body as html  
                message.Body = "Message: Enter the following OTP:" + OTP.ToString();
                smtp.Port = 587;
                smtp.Host = "smtp.gmail.com"; //for gmail host  
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential("garikainharara@gmail.com", "Faithgary05");
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(message);
            }
            catch (Exception) { }
        }



        [HttpPost("OTPch")]
        public IActionResult EnterOTP([FromBody] int eOTP)
        {
            if (OTP == eOTP)
            {
                return Ok(true);
            }
            else
            {
                return Ok(false);
            }
        }

        
        
        [HttpPost("CreateUser")]
        public IActionResult addUser([FromBody] Login login)
        {

            try
            {
                bool flag1 = false;
                Login item = new Login();
                item.passWord = Hash(login.passWord);
                item.userName = login.userName;
                foreach (var thing in _dbContext.Login)
                {
                    if (thing.userName == item.userName)
                    {
                        flag1 = true;
                        return Ok(false);
                    }

                }
                if (flag1 == false)
                {
                    _dbContext.Login.Add(item);
                    _dbContext.SaveChanges();
                    return Ok(true);
                }
                else
                {
                    return Ok(false);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Something went wrong");
            }


        }
    }

}


